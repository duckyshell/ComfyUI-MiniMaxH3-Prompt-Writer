export function generateModelSummaryMarkup(icon) {
  return `
    <button class="h3ps-active-model" type="button" title="Open model settings" data-open-settings>
      <span class="h3ps-active-model-icon h3ps-provider-icon" data-active-model-icon data-provider-icon="direct" aria-hidden="true"></span>
      <span><small data-active-model-source>Prompt model</small><strong data-active-model-name>Scanning models…</strong></span>
      <em data-active-runtime-summary>Runtime · Auto</em>
      ${icon("chevron", 14)}
    </button>`;
}

function systemPromptPanel(profile, label, description, icon, hidden = false) {
  return `
    <div class="h3ps-system-prompt-panel" data-system-prompt-panel="${profile}" ${hidden ? "hidden" : ""}>
      <header class="h3ps-system-prompt-editor-heading">
        <button type="button" data-system-prompt-back>${icon("chevron", 12)} Back</button>
        <span><small>System Prompt</small><strong>${label}</strong></span>
        <span class="h3ps-system-prompt-panel-status"><em data-system-prompt-status="${profile}">Default</em>${icon("check", 13)}</span>
      </header>
      <p>${description} Official MiniMax guides are applied separately and are not modified.</p>
      <textarea data-system-prompt="${profile}" maxlength="8000" spellcheck="true" disabled></textarea>
      <footer><small data-system-prompt-count="${profile}">0 / 8,000</small><button type="button" data-system-prompt-reset="${profile}" hidden>Reset to default</button></footer>
    </div>`;
}

export function settingsMarkup(icon) {
  return `
    <section class="h3ps-settings-view" data-settings-view hidden>
      <header class="h3ps-settings-heading">
        <span><strong>Settings</strong><em>Inference, runtime and prompt behavior</em></span>
        <button class="h3ps-secondary-button" type="button" data-close-settings>${icon("chevron", 14)} Back to Generate</button>
      </header>

      <div class="h3ps-settings-content">
        <section class="h3ps-settings-card h3ps-provider-settings">
          <header><span><small>Inference</small><strong>Provider</strong></span></header>
          <div class="h3ps-provider-selector" role="tablist" aria-label="Inference provider">
            <button type="button" role="tab" data-provider-option="ollama" aria-selected="true">
              <span class="h3ps-provider-icon" data-provider-icon="ollama" aria-hidden="true"></span><span><strong>Ollama</strong><small>Simple local model service</small></span>${icon("check", 14)}
            </button>
            <button type="button" role="tab" data-provider-option="direct" aria-selected="false">
              <span class="h3ps-provider-icon" data-provider-icon="direct" aria-hidden="true"></span><span><strong>Direct GGUF</strong><small>Models installed in ComfyUI</small></span>${icon("check", 14)}
            </button>
            <button type="button" role="tab" data-provider-option="external" aria-selected="false">
              <span class="h3ps-provider-icon" data-provider-icon="external" aria-hidden="true"></span><span><strong>External llama.cpp</strong><small>Existing local llama-server</small></span>${icon("check", 14)}
            </button>
            <button type="button" role="tab" data-provider-option="api" aria-selected="false">
              <span class="h3ps-provider-icon" data-provider-icon="api" aria-hidden="true"></span><span><strong>API providers</strong><small>OpenAI-compatible local or remote API</small></span>${icon("check", 14)}
            </button>
          </div>
        </section>

        <section class="h3ps-settings-card h3ps-provider-detail" data-provider-detail>
          <div class="h3ps-provider-panel" data-provider-panel="direct" hidden>
            <div data-direct-runtime-status></div>
            <header class="h3ps-settings-section-heading">
              <span><small>Model</small><strong>Installed models</strong></span>
              <button class="h3ps-small-refresh" type="button" data-model-refresh>${icon("refresh", 13)} Refresh</button>
            </header>
            <div class="h3ps-installed-model-heading">Select Model</div>
            <div class="h3ps-installed-model-control">
              <span class="h3ps-model-icon h3ps-provider-icon" data-provider-icon="direct" aria-hidden="true"></span>
              <label><select data-installed-model aria-label="Installed model"><option>Scanning models…</option></select></label>
              <span class="h3ps-model-lifecycle" data-model-lifecycle hidden><em data-model-lifecycle-label>Model loaded</em></span>
            </div>
            <p class="h3ps-installed-model-source" data-model-source-label>Local GGUF · llama-cpp-python</p>
            <div data-direct-model-status></div>
            <div class="h3ps-model-utilities">
              <div data-model-scan-slot></div>
              <div data-verified-models-slot></div>
            </div>
          </div>

          <div class="h3ps-provider-panel" data-provider-panel="external" hidden>
            <header class="h3ps-settings-section-heading"><span><small>Connection</small><strong>External llama.cpp server</strong></span></header>
            <div data-external-provider-control></div>
          </div>

          <div class="h3ps-provider-panel" data-provider-panel="ollama">
            <div data-ollama-provider-control></div>
          </div>

          <div class="h3ps-provider-panel" data-provider-panel="api" hidden>
            <div data-api-provider-control></div>
          </div>

        </section>

        <section class="h3ps-settings-card h3ps-runtime-settings">
          <header><span><small>Runtime</small><strong>Context</strong></span></header>
          <div class="h3ps-runtime-settings-grid">
            <div class="h3ps-runtime-control"><span>Context</span><span class="h3ps-runtime-picker"><button type="button" data-runtime-toggle="context"><b data-runtime-label="context">Auto</b>${icon("chevron", 12)}</button><span class="h3ps-runtime-menu" data-runtime-menu="context" hidden><button type="button" data-runtime-option="context" data-value="auto">Auto</button><button type="button" data-runtime-option="context" data-value="low">8K</button><button type="button" data-runtime-option="context" data-value="standard">16K</button><button type="button" data-runtime-option="context" data-value="extended">24K</button><button type="button" data-runtime-option="context" data-value="large">32K</button><button type="button" data-runtime-option="context" data-value="maximum">48K</button><button type="button" data-runtime-option="context" data-value="custom">Custom</button></span></span><label class="h3ps-runtime-custom" data-custom-context hidden><input type="number" min="1024" step="1" inputmode="numeric" placeholder="Enter tokens" data-custom-context-input><span>tokens</span></label></div>
          </div>
          <details class="h3ps-direct-advanced" data-direct-runtime-advanced>
            <summary><strong>Advanced settings</strong><em data-direct-advanced-summary>Auto</em>${icon("chevron", 12)}</summary>
            <div class="h3ps-direct-advanced-body">
              <div class="h3ps-runtime-control"><span>KV cache</span><span class="h3ps-runtime-picker"><button type="button" data-runtime-toggle="kv"><b data-runtime-label="kv">Auto</b>${icon("chevron", 12)}</button><span class="h3ps-runtime-menu" data-runtime-menu="kv" hidden><button type="button" data-runtime-option="kv" data-value="auto">Auto</button><button type="button" data-runtime-option="kv" data-value="q8">Q8</button><button type="button" data-runtime-option="kv" data-value="f16">F16</button></span></span></div>
              <div class="h3ps-runtime-control"><span>Generation budget</span><span class="h3ps-runtime-picker"><button type="button" data-runtime-toggle="budget"><b data-runtime-label="budget">Auto</b>${icon("chevron", 12)}</button><span class="h3ps-runtime-menu" data-runtime-menu="budget" hidden><button type="button" data-runtime-option="budget" data-value="auto">Auto</button><button type="button" data-runtime-option="budget" data-value="2048">2K</button><button type="button" data-runtime-option="budget" data-value="4096">4K</button><button type="button" data-runtime-option="budget" data-value="8192">8K</button><button type="button" data-runtime-option="budget" data-value="custom">Custom</button></span></span><label class="h3ps-runtime-custom" data-custom-generation-budget hidden><input type="number" min="1" step="1" inputmode="numeric" placeholder="Enter tokens" data-custom-generation-budget-input><span>tokens</span></label></div>
              <div class="h3ps-runtime-control" data-reasoning-effort-control hidden><span>Reasoning effort</span><span class="h3ps-runtime-picker"><button type="button" data-runtime-toggle="reasoning"><b data-runtime-label="reasoning">Auto</b>${icon("chevron", 12)}</button><span class="h3ps-runtime-menu" data-runtime-menu="reasoning" hidden></span></span></div>
            </div>
          </details>
          <p data-runtime-management>Direct GGUF runtime settings are applied to the next request.</p>
        </section>

        <section class="h3ps-settings-card h3ps-system-prompt-card">
          <header><span><small>Prompt behavior · shared by all providers</small><strong>System Prompt</strong></span></header>
          <div class="h3ps-system-prompt-overview" data-system-prompt-overview>
            <button type="button" data-system-prompt-profile="standard">
              <span><strong>Standard</strong><small>T2VA · I2VA · FL2VA · L2VA</small></span>
              <span><em data-system-prompt-summary-status="standard">Default</em><b>Edit</b>${icon("chevron", 12)}</span>
            </button>
            <button type="button" data-system-prompt-profile="reference">
              <span><strong>Reference</strong><small>Reference mode</small></span>
              <span><em data-system-prompt-summary-status="reference">Default</em><b>Edit</b>${icon("chevron", 12)}</span>
            </button>
          </div>
          <div class="h3ps-system-prompt-editor" data-system-prompt-editor hidden>
            ${systemPromptPanel("standard", "Standard", "Instructions used by T2VA, I2VA, FL2VA and L2VA.", icon)}
            ${systemPromptPanel("reference", "Reference", "Instructions used by Reference mode.", icon, true)}
          </div>
          <div class="h3ps-draft-defaults-action" data-draft-defaults-action>
            <button type="button" data-restore-default-drafts>${icon("refresh", 13)}<span data-restore-default-drafts-label>Restore default drafts</span></button>
          </div>
        </section>
      </div>
    </section>`;
}
